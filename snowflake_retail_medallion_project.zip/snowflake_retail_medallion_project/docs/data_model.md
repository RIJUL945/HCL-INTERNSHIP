# Retail Data Model

```mermaid
erDiagram
  DIM_DATE ||--o{ FACT_SALES : date_key
  DIM_CUSTOMER ||--o{ FACT_SALES : customer_key
  DIM_STORE ||--o{ FACT_SALES : store_key
  DIM_PRODUCT ||--o{ FACT_SALES : product_key
  DIM_PROMOTION ||--o{ FACT_SALES : promotion_key
  DIM_DATE ||--o{ FACT_RETURNS : date_key
  DIM_STORE ||--o{ FACT_RETURNS : store_key
  DIM_PRODUCT ||--o{ FACT_RETURNS : product_key
  DIM_DATE ||--o{ FACT_INVENTORY_DAILY : date_key
  DIM_STORE ||--o{ FACT_INVENTORY_DAILY : store_key
  DIM_PRODUCT ||--o{ FACT_INVENTORY_DAILY : product_key
```

## Grain
- FACT_SALES: one row per order line.
- FACT_RETURNS: one row per returned order product.
- FACT_INVENTORY_DAILY: one row per date, store, and product.
