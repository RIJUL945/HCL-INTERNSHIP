# Source-to-Target Summary

| Source file | Bronze table | Silver table | Gold target |
|---|---|---|---|
| stores.csv | RAW_STORES | STORE | DIM_STORE |
| products.csv | RAW_PRODUCTS | PRODUCT | DIM_PRODUCT |
| customers.csv | RAW_CUSTOMERS | CUSTOMER | DIM_CUSTOMER |
| promotions.csv | RAW_PROMOTIONS | PROMOTION | DIM_PROMOTION |
| orders.csv | RAW_ORDERS | ORDERS | FACT_SALES |
| order_items.csv | RAW_ORDER_ITEMS | ORDER_ITEM | FACT_SALES |
| returns.csv | RAW_RETURNS | RETURN_ITEM | FACT_RETURNS |
| inventory_snapshot.csv | RAW_INVENTORY_SNAPSHOT | INVENTORY_SNAPSHOT | FACT_INVENTORY_DAILY |
| payments.csv | RAW_PAYMENTS | PAYMENT | Optional payment analysis |
