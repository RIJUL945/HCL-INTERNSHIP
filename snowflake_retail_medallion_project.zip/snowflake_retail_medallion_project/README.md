# Snowflake Retail Analytics – Medallion Practice Project

## Business scenario
A fictional omnichannel retailer receives daily CSV files for stores, products, customers, promotions,
orders, order items, payments, returns, and inventory. The goal is to build a governed Snowflake
analytics platform and expose BI-ready retail KPIs.

## Architecture
Files → Internal Stage → Bronze raw transient tables → Silver cleansed/conformed tables →
Gold star schema → Secure BI views → Power BI/Tableau/Snowsight.

## Gold model
Dimensions: DIM_DATE, DIM_STORE, DIM_PRODUCT, DIM_PROMOTION, DIM_CUSTOMER (SCD2).
Facts: FACT_SALES (order-line grain), FACT_RETURNS, FACT_INVENTORY_DAILY.

## Run order
1. Run `sql/00_project_setup.sql` as ACCOUNTADMIN.
2. Run `01_file_formats_and_stage.sql`.
3. Run `02_bronze_ddl.sql`.
4. Upload `data/*.csv` using the PUT command shown in script 01.
5. Run `03_copy_into_bronze.sql`.
6. Run `04_silver_ddl.sql` and `05_silver_transform.sql`.
7. Run `06_gold_star_schema.sql`.
8. Run `09_bi_views_and_kpis.sql`.
9. Run `10_data_quality_tests.sql`.
10. Add incremental processing with `07_incremental_streams_tasks.sql`.
11. Add governance, monitoring, cloning, sharing, and unloading with scripts 08, 11, and 12.
12. Optionally try Dynamic Tables using script 13.

## Suggested BI dashboard pages
- Executive overview: net sales, orders, units, AOV, discount rate, return amount.
- Sales trend: daily/monthly trend, YoY/MoM comparison.
- Product: category, brand, top/bottom products.
- Store/channel: region, store ranking, online-vs-store mix.
- Customer: loyalty tier, repeat customers, customer lifetime sales.
- Inventory: low-stock SKUs, stock by store, reorder alerts.
- Returns: return amount/rate and reason analysis.

## Student exercises
1. Add malformed records and inspect COPY errors.
2. Change a customer's loyalty tier and implement an SCD2 update.
3. Add a new daily order file and process it through a stream-triggered task.
4. Compare warehouse sizes and query profiles.
5. Test masking with RETAIL_ADMIN versus RETAIL_BI.
6. Use zero-copy clone before changing the Gold model.
7. Query a table using Time Travel, then practice UNDROP.
8. Unload a daily KPI extract.
9. Share a secure KPI view with a consumer account.
10. Replace one stream/task pipeline with a Dynamic Table.

## Important lab notes
- Snowflake declares primary/foreign key constraints on standard tables but generally does not enforce them;
  the DQ tests therefore validate uniqueness and referential integrity.
- Account Usage views have latency.
- Sharing, some governance features, and multi-cluster behavior depend on edition and privileges.
- Keep X-Small warehouses with auto-suspend for a student account.
