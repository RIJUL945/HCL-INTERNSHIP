USE ROLE RETAIL_ENGINEER;
USE DATABASE RETAIL_DB;
USE SCHEMA GOLD;

CREATE OR REPLACE SECURE VIEW VW_SALES_DETAIL AS
SELECT d.full_date,s.store_name,s.city,s.region,p.product_name,p.category,p.brand,
 c.customer_id,c.customer_name,c.loyalty_tier,fs.order_id,fs.channel,fs.order_status,
 fs.quantity,fs.gross_sales_amount,fs.discount_amount,fs.net_sales_amount,fs.tax_amount,
 fs.total_sales_amount
FROM FACT_SALES fs
JOIN DIM_DATE d ON fs.date_key=d.date_key
JOIN DIM_STORE s ON fs.store_key=s.store_key
JOIN DIM_PRODUCT p ON fs.product_key=p.product_key
JOIN DIM_CUSTOMER c ON fs.customer_key=c.customer_key;

CREATE OR REPLACE VIEW VW_DAILY_SALES_KPI AS
SELECT d.full_date,s.region,
 SUM(IFF(fs.order_status='COMPLETED',fs.net_sales_amount,0)) net_sales,
 COUNT(DISTINCT IFF(fs.order_status='COMPLETED',fs.order_id,NULL)) orders,
 SUM(IFF(fs.order_status='COMPLETED',fs.quantity,0)) units,
 DIV0(SUM(IFF(fs.order_status='COMPLETED',fs.net_sales_amount,0)),
      COUNT(DISTINCT IFF(fs.order_status='COMPLETED',fs.order_id,NULL))) average_order_value,
 DIV0(SUM(fs.discount_amount),SUM(fs.gross_sales_amount)) discount_rate
FROM FACT_SALES fs
JOIN DIM_DATE d ON fs.date_key=d.date_key
JOIN DIM_STORE s ON fs.store_key=s.store_key
GROUP BY 1,2;

CREATE OR REPLACE VIEW VW_PRODUCT_PERFORMANCE AS
SELECT p.category,p.brand,p.product_name,
 SUM(IFF(fs.order_status='COMPLETED',fs.quantity,0)) units_sold,
 SUM(IFF(fs.order_status='COMPLETED',fs.net_sales_amount,0)) net_sales,
 SUM(COALESCE(fr.return_amount,0)) return_amount
FROM FACT_SALES fs
JOIN DIM_PRODUCT p ON fs.product_key=p.product_key
LEFT JOIN (
 SELECT order_id,product_key,SUM(return_amount) return_amount
 FROM FACT_RETURNS GROUP BY 1,2
) fr ON fs.order_id=fr.order_id AND fs.product_key=fr.product_key
GROUP BY 1,2,3;

CREATE OR REPLACE VIEW VW_INVENTORY_ALERTS AS
SELECT d.full_date,s.store_name,p.product_name,p.category,
 f.on_hand_qty,f.reorder_level,f.low_stock_flag
FROM FACT_INVENTORY_DAILY f
JOIN DIM_DATE d ON f.date_key=d.date_key
JOIN DIM_STORE s ON f.store_key=s.store_key
JOIN DIM_PRODUCT p ON f.product_key=p.product_key
WHERE f.low_stock_flag;

-- BI questions:
-- 1. Sales trend by day/week/month
-- 2. Store and region performance
-- 3. Online vs store channel mix
-- 4. Category/brand/product contribution
-- 5. Average order value and discount rate
-- 6. Return rate and return reasons
-- 7. Low-stock products and inventory coverage
-- 8. Loyalty-tier revenue and repeat customers
