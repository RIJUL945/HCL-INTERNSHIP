USE ROLE RETAIL_ENGINEER;
USE DATABASE RETAIL_DB;
USE SCHEMA BRONZE;
USE WAREHOUSE RETAIL_INGEST_WH;

COPY INTO RAW_STORES(store_id,store_name,city,state,region,open_date,source_file)
FROM (SELECT $1,$2,$3,$4,$5,$6,METADATA$FILENAME FROM @RETAIL_FILES_STAGE/stores)
FILE_FORMAT=(FORMAT_NAME=CSV_FF) ON_ERROR='ABORT_STATEMENT';

COPY INTO RAW_PRODUCTS(product_id,product_name,category,brand,list_price,active_flag,source_file)
FROM (SELECT $1,$2,$3,$4,$5,$6,METADATA$FILENAME FROM @RETAIL_FILES_STAGE/products)
FILE_FORMAT=(FORMAT_NAME=CSV_FF) ON_ERROR='CONTINUE';

COPY INTO RAW_CUSTOMERS(customer_id,customer_name,email,phone,city,state,join_date,loyalty_tier,source_file)
FROM (SELECT $1,$2,$3,$4,$5,$6,$7,$8,METADATA$FILENAME FROM @RETAIL_FILES_STAGE/customers)
FILE_FORMAT=(FORMAT_NAME=CSV_FF) ON_ERROR='CONTINUE';

COPY INTO RAW_PROMOTIONS(promotion_id,promotion_code,discount_type,discount_value,start_date,end_date,source_file)
FROM (SELECT $1,$2,$3,$4,$5,$6,METADATA$FILENAME FROM @RETAIL_FILES_STAGE/promotions)
FILE_FORMAT=(FORMAT_NAME=CSV_FF) ON_ERROR='CONTINUE';

COPY INTO RAW_ORDERS(order_id,order_date,customer_id,store_id,channel,order_status,promotion_id,
 subtotal_amount,discount_amount,tax_amount,total_amount,source_file)
FROM (SELECT $1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,METADATA$FILENAME FROM @RETAIL_FILES_STAGE/orders)
FILE_FORMAT=(FORMAT_NAME=CSV_FF) ON_ERROR='CONTINUE';

COPY INTO RAW_ORDER_ITEMS(order_id,line_number,product_id,quantity,unit_price,discount_amount,net_amount,source_file)
FROM (SELECT $1,$2,$3,$4,$5,$6,$7,METADATA$FILENAME FROM @RETAIL_FILES_STAGE/order_items)
FILE_FORMAT=(FORMAT_NAME=CSV_FF) ON_ERROR='CONTINUE';

COPY INTO RAW_PAYMENTS(payment_id,order_id,payment_date,payment_method,payment_amount,payment_status,source_file)
FROM (SELECT $1,$2,$3,$4,$5,$6,METADATA$FILENAME FROM @RETAIL_FILES_STAGE/payments)
FILE_FORMAT=(FORMAT_NAME=CSV_FF) ON_ERROR='CONTINUE';

COPY INTO RAW_RETURNS(return_id,order_id,product_id,return_date,return_reason,return_amount,source_file)
FROM (SELECT $1,$2,$3,$4,$5,$6,METADATA$FILENAME FROM @RETAIL_FILES_STAGE/returns)
FILE_FORMAT=(FORMAT_NAME=CSV_FF) ON_ERROR='CONTINUE';

COPY INTO RAW_INVENTORY_SNAPSHOT(snapshot_date,store_id,product_id,on_hand_qty,reorder_level,source_file)
FROM (SELECT $1,$2,$3,$4,$5,METADATA$FILENAME FROM @RETAIL_FILES_STAGE/inventory_snapshot)
FILE_FORMAT=(FORMAT_NAME=CSV_FF) ON_ERROR='CONTINUE';

-- Inspect load history and rejected files:
SELECT * FROM TABLE(INFORMATION_SCHEMA.COPY_HISTORY(
 TABLE_NAME=>'RETAIL_DB.BRONZE.RAW_ORDERS',
 START_TIME=>DATEADD('hour',-24,CURRENT_TIMESTAMP())));
