USE ROLE RETAIL_ENGINEER;
USE DATABASE RETAIL_DB;
USE WAREHOUSE RETAIL_TRANSFORM_WH;

MERGE INTO SILVER.STORE t USING (
 SELECT store_id,store_name,city,state,region,TRY_TO_DATE(open_date) open_date,
        SHA2(CONCAT_WS('|',store_name,city,state,region,open_date),256) record_hash
 FROM BRONZE.RAW_STORES
 QUALIFY ROW_NUMBER() OVER(PARTITION BY store_id ORDER BY load_ts DESC)=1
) s ON t.store_id=s.store_id
WHEN MATCHED AND t.record_hash<>s.record_hash THEN UPDATE SET
 store_name=s.store_name,city=s.city,state=s.state,region=s.region,open_date=s.open_date,
 record_hash=s.record_hash,updated_ts=CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN INSERT VALUES
 (s.store_id,s.store_name,s.city,s.state,s.region,s.open_date,s.record_hash,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP());

MERGE INTO SILVER.PRODUCT t USING (
 SELECT product_id,product_name,category,brand,TRY_TO_DECIMAL(list_price,12,2) list_price,
        IFF(UPPER(active_flag)='Y',TRUE,FALSE) active_flag,
        SHA2(CONCAT_WS('|',product_name,category,brand,list_price,active_flag),256) record_hash
 FROM BRONZE.RAW_PRODUCTS
 WHERE TRY_TO_DECIMAL(list_price,12,2) IS NOT NULL
 QUALIFY ROW_NUMBER() OVER(PARTITION BY product_id ORDER BY load_ts DESC)=1
) s ON t.product_id=s.product_id
WHEN MATCHED AND t.record_hash<>s.record_hash THEN UPDATE SET
 product_name=s.product_name,category=s.category,brand=s.brand,list_price=s.list_price,
 active_flag=s.active_flag,record_hash=s.record_hash,updated_ts=CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN INSERT VALUES
 (s.product_id,s.product_name,s.category,s.brand,s.list_price,s.active_flag,s.record_hash,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP());

MERGE INTO SILVER.CUSTOMER t USING (
 SELECT customer_id,INITCAP(TRIM(customer_name)) customer_name,LOWER(TRIM(email)) email,
        REGEXP_REPLACE(phone,'[^0-9]','') phone,INITCAP(city) city,INITCAP(state) state,
        TRY_TO_DATE(join_date) join_date,UPPER(loyalty_tier) loyalty_tier,
        SHA2(CONCAT_WS('|',customer_name,email,phone,city,state,join_date,loyalty_tier),256) record_hash
 FROM BRONZE.RAW_CUSTOMERS
 WHERE customer_id IS NOT NULL AND email ILIKE '%@%'
 QUALIFY ROW_NUMBER() OVER(PARTITION BY customer_id ORDER BY load_ts DESC)=1
) s ON t.customer_id=s.customer_id
WHEN MATCHED AND t.record_hash<>s.record_hash THEN UPDATE SET
 customer_name=s.customer_name,email=s.email,phone=s.phone,city=s.city,state=s.state,
 join_date=s.join_date,loyalty_tier=s.loyalty_tier,record_hash=s.record_hash,updated_ts=CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN INSERT VALUES
 (s.customer_id,s.customer_name,s.email,s.phone,s.city,s.state,s.join_date,s.loyalty_tier,
  s.record_hash,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP());

MERGE INTO SILVER.PROMOTION t USING (
 SELECT promotion_id,promotion_code,discount_type,TRY_TO_DECIMAL(discount_value,12,2) discount_value,
        TRY_TO_DATE(start_date) start_date,TRY_TO_DATE(end_date) end_date,
        SHA2(CONCAT_WS('|',promotion_code,discount_type,discount_value,start_date,end_date),256) record_hash
 FROM BRONZE.RAW_PROMOTIONS
 QUALIFY ROW_NUMBER() OVER(PARTITION BY promotion_id ORDER BY load_ts DESC)=1
) s ON t.promotion_id=s.promotion_id
WHEN MATCHED AND t.record_hash<>s.record_hash THEN UPDATE SET
 promotion_code=s.promotion_code,discount_type=s.discount_type,discount_value=s.discount_value,
 start_date=s.start_date,end_date=s.end_date,record_hash=s.record_hash,updated_ts=CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN INSERT VALUES
 (s.promotion_id,s.promotion_code,s.discount_type,s.discount_value,s.start_date,s.end_date,
  s.record_hash,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP());

MERGE INTO SILVER.ORDERS t USING (
 SELECT order_id,TRY_TO_DATE(order_date) order_date,customer_id,store_id,UPPER(channel) channel,
        UPPER(order_status) order_status,promotion_id,
        TRY_TO_DECIMAL(subtotal_amount,14,2) subtotal_amount,
        TRY_TO_DECIMAL(discount_amount,14,2) discount_amount,
        TRY_TO_DECIMAL(tax_amount,14,2) tax_amount,
        TRY_TO_DECIMAL(total_amount,14,2) total_amount
 FROM BRONZE.RAW_ORDERS
 WHERE TRY_TO_DATE(order_date) IS NOT NULL
 QUALIFY ROW_NUMBER() OVER(PARTITION BY order_id ORDER BY load_ts DESC)=1
) s ON t.order_id=s.order_id
WHEN MATCHED THEN UPDATE SET
 order_date=s.order_date,customer_id=s.customer_id,store_id=s.store_id,channel=s.channel,
 order_status=s.order_status,promotion_id=s.promotion_id,subtotal_amount=s.subtotal_amount,
 discount_amount=s.discount_amount,tax_amount=s.tax_amount,total_amount=s.total_amount,updated_ts=CURRENT_TIMESTAMP()
WHEN NOT MATCHED THEN INSERT VALUES
 (s.order_id,s.order_date,s.customer_id,s.store_id,s.channel,s.order_status,s.promotion_id,
  s.subtotal_amount,s.discount_amount,s.tax_amount,s.total_amount,CURRENT_TIMESTAMP(),CURRENT_TIMESTAMP());

MERGE INTO SILVER.ORDER_ITEM t USING (
 SELECT order_id,TRY_TO_NUMBER(line_number) line_number,product_id,TRY_TO_NUMBER(quantity) quantity,
        TRY_TO_DECIMAL(unit_price,12,2) unit_price,TRY_TO_DECIMAL(discount_amount,12,2) discount_amount,
        TRY_TO_DECIMAL(net_amount,14,2) net_amount
 FROM BRONZE.RAW_ORDER_ITEMS
 WHERE TRY_TO_NUMBER(quantity)>0
 QUALIFY ROW_NUMBER() OVER(PARTITION BY order_id,line_number ORDER BY load_ts DESC)=1
) s ON t.order_id=s.order_id AND t.line_number=s.line_number
WHEN MATCHED THEN UPDATE SET product_id=s.product_id,quantity=s.quantity,unit_price=s.unit_price,
 discount_amount=s.discount_amount,net_amount=s.net_amount
WHEN NOT MATCHED THEN INSERT VALUES
 (s.order_id,s.line_number,s.product_id,s.quantity,s.unit_price,s.discount_amount,s.net_amount,CURRENT_TIMESTAMP());

INSERT OVERWRITE INTO SILVER.PAYMENT
SELECT payment_id,order_id,TRY_TO_DATE(payment_date),UPPER(payment_method),
 TRY_TO_DECIMAL(payment_amount,14,2),UPPER(payment_status),CURRENT_TIMESTAMP()
FROM BRONZE.RAW_PAYMENTS
QUALIFY ROW_NUMBER() OVER(PARTITION BY payment_id ORDER BY load_ts DESC)=1;

INSERT OVERWRITE INTO SILVER.RETURN_ITEM
SELECT return_id,order_id,product_id,TRY_TO_DATE(return_date),UPPER(return_reason),
 TRY_TO_DECIMAL(return_amount,14,2),CURRENT_TIMESTAMP()
FROM BRONZE.RAW_RETURNS
QUALIFY ROW_NUMBER() OVER(PARTITION BY return_id ORDER BY load_ts DESC)=1;

INSERT OVERWRITE INTO SILVER.INVENTORY_SNAPSHOT
SELECT TRY_TO_DATE(snapshot_date),store_id,product_id,TRY_TO_NUMBER(on_hand_qty),
 TRY_TO_NUMBER(reorder_level),CURRENT_TIMESTAMP()
FROM BRONZE.RAW_INVENTORY_SNAPSHOT
QUALIFY ROW_NUMBER() OVER(PARTITION BY snapshot_date,store_id,product_id ORDER BY load_ts DESC)=1;
