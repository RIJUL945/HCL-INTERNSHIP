-- Alternative declarative pipeline lab. Use this instead of streams/tasks for selected transformations.
USE ROLE RETAIL_ENGINEER;
USE DATABASE RETAIL_DB;
USE WAREHOUSE RETAIL_TRANSFORM_WH;

CREATE OR REPLACE DYNAMIC TABLE SILVER.DT_ORDERS_CLEAN
 TARGET_LAG='15 minutes'
 WAREHOUSE=RETAIL_TRANSFORM_WH
AS
SELECT order_id,TRY_TO_DATE(order_date) order_date,customer_id,store_id,UPPER(channel) channel,
 UPPER(order_status) order_status,promotion_id,
 TRY_TO_DECIMAL(subtotal_amount,14,2) subtotal_amount,
 TRY_TO_DECIMAL(discount_amount,14,2) discount_amount,
 TRY_TO_DECIMAL(tax_amount,14,2) tax_amount,
 TRY_TO_DECIMAL(total_amount,14,2) total_amount
FROM BRONZE.RAW_ORDERS
WHERE TRY_TO_DATE(order_date) IS NOT NULL
QUALIFY ROW_NUMBER() OVER(PARTITION BY order_id ORDER BY load_ts DESC)=1;

SHOW DYNAMIC TABLES LIKE 'DT_ORDERS_CLEAN' IN SCHEMA SILVER;
