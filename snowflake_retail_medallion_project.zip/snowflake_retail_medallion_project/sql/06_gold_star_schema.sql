USE ROLE RETAIL_ENGINEER;
USE DATABASE RETAIL_DB;
USE SCHEMA GOLD;
USE WAREHOUSE RETAIL_TRANSFORM_WH;

CREATE OR REPLACE TABLE DIM_DATE AS
SELECT
 TO_NUMBER(TO_CHAR(d,'YYYYMMDD')) date_key, d full_date,
 YEAR(d) year, QUARTER(d) quarter, MONTH(d) month_number, MONTHNAME(d) month_name,
 WEEKOFYEAR(d) week_number, DAYOFWEEKISO(d) day_of_week, DAYNAME(d) day_name,
 IFF(DAYOFWEEKISO(d) IN (6,7),TRUE,FALSE) is_weekend
FROM (
 SELECT DATEADD(day,SEQ4(),'2024-01-01'::DATE) d
 FROM TABLE(GENERATOR(ROWCOUNT=>1461))
);

CREATE OR REPLACE TABLE DIM_STORE AS
SELECT ROW_NUMBER() OVER(ORDER BY store_id) store_key, store_id,store_name,city,state,region,open_date
FROM SILVER.STORE;

CREATE OR REPLACE TABLE DIM_PRODUCT AS
SELECT ROW_NUMBER() OVER(ORDER BY product_id) product_key, product_id,product_name,category,brand,list_price,active_flag
FROM SILVER.PRODUCT;

CREATE OR REPLACE TABLE DIM_PROMOTION AS
SELECT ROW_NUMBER() OVER(ORDER BY promotion_id) promotion_key,promotion_id,promotion_code,
 discount_type,discount_value,start_date,end_date
FROM SILVER.PROMOTION;

-- Customer SCD Type 2
CREATE OR REPLACE TABLE DIM_CUSTOMER (
 customer_key NUMBER AUTOINCREMENT, customer_id STRING, customer_name STRING, email STRING, phone STRING,
 city STRING,state STRING,join_date DATE,loyalty_tier STRING,effective_from TIMESTAMP_LTZ,
 effective_to TIMESTAMP_LTZ,is_current BOOLEAN,record_hash STRING
);

INSERT INTO DIM_CUSTOMER(customer_id,customer_name,email,phone,city,state,join_date,loyalty_tier,
 effective_from,effective_to,is_current,record_hash)
SELECT customer_id,customer_name,email,phone,city,state,join_date,loyalty_tier,
 CURRENT_TIMESTAMP(),'9999-12-31'::TIMESTAMP_LTZ,TRUE,record_hash
FROM SILVER.CUSTOMER;

CREATE OR REPLACE TABLE FACT_SALES AS
SELECT
 TO_NUMBER(TO_CHAR(o.order_date,'YYYYMMDD')) date_key,
 dc.customer_key, ds.store_key, dp.product_key, dpr.promotion_key,
 o.order_id, oi.line_number, o.channel, o.order_status,
 oi.quantity, oi.unit_price,
 (oi.quantity*oi.unit_price) gross_sales_amount,
 oi.discount_amount,
 oi.net_amount net_sales_amount,
 ROUND(oi.net_amount*0.18,2) tax_amount,
 ROUND(oi.net_amount*1.18,2) total_sales_amount
FROM SILVER.ORDERS o
JOIN SILVER.ORDER_ITEM oi ON o.order_id=oi.order_id
JOIN DIM_CUSTOMER dc ON dc.customer_id=o.customer_id AND dc.is_current
JOIN DIM_STORE ds ON ds.store_id=o.store_id
JOIN DIM_PRODUCT dp ON dp.product_id=oi.product_id
LEFT JOIN DIM_PROMOTION dpr ON dpr.promotion_id=o.promotion_id;

CREATE OR REPLACE TABLE FACT_RETURNS AS
SELECT TO_NUMBER(TO_CHAR(r.return_date,'YYYYMMDD')) date_key,
 ds.store_key, dp.product_key, r.order_id, r.return_id, r.return_reason, r.return_amount
FROM SILVER.RETURN_ITEM r
JOIN SILVER.ORDERS o ON r.order_id=o.order_id
JOIN DIM_STORE ds ON ds.store_id=o.store_id
JOIN DIM_PRODUCT dp ON dp.product_id=r.product_id;

CREATE OR REPLACE TABLE FACT_INVENTORY_DAILY AS
SELECT TO_NUMBER(TO_CHAR(i.snapshot_date,'YYYYMMDD')) date_key,
 ds.store_key,dp.product_key,i.on_hand_qty,i.reorder_level,
 IFF(i.on_hand_qty<=i.reorder_level,TRUE,FALSE) low_stock_flag
FROM SILVER.INVENTORY_SNAPSHOT i
JOIN DIM_STORE ds ON ds.store_id=i.store_id
JOIN DIM_PRODUCT dp ON dp.product_id=i.product_id;
