USE ROLE RETAIL_ENGINEER;
USE DATABASE RETAIL_DB;
USE SCHEMA SILVER;

CREATE OR REPLACE TABLE STORE (
 store_id STRING PRIMARY KEY, store_name STRING, city STRING, state STRING, region STRING, open_date DATE,
 record_hash STRING, created_ts TIMESTAMP_LTZ, updated_ts TIMESTAMP_LTZ
);
CREATE OR REPLACE TABLE PRODUCT (
 product_id STRING PRIMARY KEY, product_name STRING, category STRING, brand STRING,
 list_price NUMBER(12,2), active_flag BOOLEAN, record_hash STRING, created_ts TIMESTAMP_LTZ, updated_ts TIMESTAMP_LTZ
);
CREATE OR REPLACE TABLE CUSTOMER (
 customer_id STRING PRIMARY KEY, customer_name STRING, email STRING, phone STRING, city STRING, state STRING,
 join_date DATE, loyalty_tier STRING, record_hash STRING, created_ts TIMESTAMP_LTZ, updated_ts TIMESTAMP_LTZ
);
CREATE OR REPLACE TABLE PROMOTION (
 promotion_id STRING PRIMARY KEY, promotion_code STRING, discount_type STRING, discount_value NUMBER(12,2),
 start_date DATE, end_date DATE, record_hash STRING, created_ts TIMESTAMP_LTZ, updated_ts TIMESTAMP_LTZ
);
CREATE OR REPLACE TABLE ORDERS (
 order_id STRING PRIMARY KEY, order_date DATE, customer_id STRING, store_id STRING, channel STRING,
 order_status STRING, promotion_id STRING, subtotal_amount NUMBER(14,2), discount_amount NUMBER(14,2),
 tax_amount NUMBER(14,2), total_amount NUMBER(14,2), created_ts TIMESTAMP_LTZ, updated_ts TIMESTAMP_LTZ
);
CREATE OR REPLACE TABLE ORDER_ITEM (
 order_id STRING, line_number NUMBER, product_id STRING, quantity NUMBER, unit_price NUMBER(12,2),
 discount_amount NUMBER(12,2), net_amount NUMBER(14,2), created_ts TIMESTAMP_LTZ,
 PRIMARY KEY(order_id,line_number)
);
CREATE OR REPLACE TABLE PAYMENT (
 payment_id STRING PRIMARY KEY, order_id STRING, payment_date DATE, payment_method STRING,
 payment_amount NUMBER(14,2), payment_status STRING, created_ts TIMESTAMP_LTZ
);
CREATE OR REPLACE TABLE RETURN_ITEM (
 return_id STRING PRIMARY KEY, order_id STRING, product_id STRING, return_date DATE,
 return_reason STRING, return_amount NUMBER(14,2), created_ts TIMESTAMP_LTZ
);
CREATE OR REPLACE TABLE INVENTORY_SNAPSHOT (
 snapshot_date DATE, store_id STRING, product_id STRING, on_hand_qty NUMBER, reorder_level NUMBER,
 created_ts TIMESTAMP_LTZ, PRIMARY KEY(snapshot_date,store_id,product_id)
);
