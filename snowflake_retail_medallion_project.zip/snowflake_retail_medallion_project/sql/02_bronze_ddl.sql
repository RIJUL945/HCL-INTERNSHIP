USE ROLE RETAIL_ENGINEER;
USE DATABASE RETAIL_DB;
USE SCHEMA BRONZE;

CREATE OR REPLACE TRANSIENT TABLE RAW_STORES (
 store_id STRING, store_name STRING, city STRING, state STRING, region STRING, open_date STRING,
 source_file STRING, load_ts TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP()
);
CREATE OR REPLACE TRANSIENT TABLE RAW_PRODUCTS (
 product_id STRING, product_name STRING, category STRING, brand STRING, list_price STRING, active_flag STRING,
 source_file STRING, load_ts TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP()
);
CREATE OR REPLACE TRANSIENT TABLE RAW_CUSTOMERS (
 customer_id STRING, customer_name STRING, email STRING, phone STRING, city STRING, state STRING,
 join_date STRING, loyalty_tier STRING, source_file STRING, load_ts TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP()
);
CREATE OR REPLACE TRANSIENT TABLE RAW_PROMOTIONS (
 promotion_id STRING, promotion_code STRING, discount_type STRING, discount_value STRING,
 start_date STRING, end_date STRING, source_file STRING, load_ts TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP()
);
CREATE OR REPLACE TRANSIENT TABLE RAW_ORDERS (
 order_id STRING, order_date STRING, customer_id STRING, store_id STRING, channel STRING,
 order_status STRING, promotion_id STRING, subtotal_amount STRING, discount_amount STRING,
 tax_amount STRING, total_amount STRING, source_file STRING, load_ts TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP()
);
CREATE OR REPLACE TRANSIENT TABLE RAW_ORDER_ITEMS (
 order_id STRING, line_number STRING, product_id STRING, quantity STRING, unit_price STRING,
 discount_amount STRING, net_amount STRING, source_file STRING, load_ts TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP()
);
CREATE OR REPLACE TRANSIENT TABLE RAW_PAYMENTS (
 payment_id STRING, order_id STRING, payment_date STRING, payment_method STRING, payment_amount STRING,
 payment_status STRING, source_file STRING, load_ts TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP()
);
CREATE OR REPLACE TRANSIENT TABLE RAW_RETURNS (
 return_id STRING, order_id STRING, product_id STRING, return_date STRING, return_reason STRING,
 return_amount STRING, source_file STRING, load_ts TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP()
);
CREATE OR REPLACE TRANSIENT TABLE RAW_INVENTORY_SNAPSHOT (
 snapshot_date STRING, store_id STRING, product_id STRING, on_hand_qty STRING, reorder_level STRING,
 source_file STRING, load_ts TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP()
);

CREATE OR REPLACE TABLE LOAD_REJECTS (
 table_name STRING, source_file STRING, error_reason STRING, rejected_record VARIANT,
 rejected_ts TIMESTAMP_LTZ DEFAULT CURRENT_TIMESTAMP()
);
